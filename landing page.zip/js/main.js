/**
 * AnticrashIA Landing Page - Main JavaScript
 * Premium dark theme with advanced animations and interactions
 */

// ==========================================
// UTILITY FUNCTIONS
// ==========================================

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function throttle(func, limit) {
    let inThrottle;
    return function(...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

// ==========================================
// MAIN APPLICATION
// ==========================================

(function() {
    'use strict';

    // Hide loading overlay immediately
    function hideLoadingOverlay() {
        const loadingOverlay = document.getElementById('loadingOverlay');
        if (loadingOverlay) {
            setTimeout(() => {
                loadingOverlay.classList.add('hidden');
            }, 300);
        }
    }

    // Initialize navigation
    function initNavigation() {
        const navToggle = document.getElementById('navToggle');
        const navLinks = document.getElementById('navLinks');

        // Mobile menu toggle
        if (navToggle && navLinks) {
            navToggle.addEventListener('click', () => {
                navToggle.classList.toggle('active');
                navLinks.classList.toggle('active');
            });

            // Close menu when clicking on links
            const links = navLinks.querySelectorAll('.nav-link');
            links.forEach(link => {
                link.addEventListener('click', () => {
                    navToggle.classList.remove('active');
                    navLinks.classList.remove('active');
                });
            });
        }

        // Smooth scroll for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                const href = anchor.getAttribute('href');
                if (href === '#' || href.length === 1) return;
                
                const target = document.querySelector(href);
                if (target) {
                    e.preventDefault();
                    const offsetTop = target.offsetTop - 80;
                    window.scrollTo({
                        top: offsetTop,
                        behavior: 'smooth'
                    });
                }
            });
        });

        // Active link highlighting
        highlightActiveSection();
    }

    function highlightActiveSection() {
        const sections = document.querySelectorAll('section[id]');
        const navLinks = document.querySelectorAll('.nav-link');

        if (!window.IntersectionObserver) return;

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const id = entry.target.getAttribute('id');
                    navLinks.forEach(link => {
                        link.classList.remove('active');
                        if (link.getAttribute('href') === `#${id}`) {
                            link.classList.add('active');
                        }
                    });
                }
            });
        }, { threshold: 0.3 });

        sections.forEach(section => observer.observe(section));
    }

    // Initialize scroll effects
    function initScrollEffects() {
        const navbar = document.getElementById('navbar');
        const backToTop = document.getElementById('backToTop');

        const handleNavbarScroll = throttle(() => {
            if (window.scrollY > 50) {
                navbar?.classList.add('scrolled');
            } else {
                navbar?.classList.remove('scrolled');
            }
        }, 100);

        const handleBackToTopScroll = throttle(() => {
            if (backToTop) {
                if (window.scrollY > 300) {
                    backToTop.classList.add('visible');
                } else {
                    backToTop.classList.remove('visible');
                }
            }
        }, 100);

        window.addEventListener('scroll', () => {
            handleNavbarScroll();
            handleBackToTopScroll();
            handleParallax();
        });

        // Back to top click
        if (backToTop) {
            backToTop.addEventListener('click', () => {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });
        }
    }

    // Parallax effect
    function handleParallax() {
        const scrolled = window.pageYOffset;
        
        // Hero parallax
        const heroImage = document.querySelector('.hero-bg-image');
        if (heroImage) {
            heroImage.style.transform = `translateY(${scrolled * 0.5}px)`;
        }

        // Floating orbs
        const orbs = document.querySelectorAll('.floating-orb');
        orbs.forEach((orb, index) => {
            const speed = 0.1 + (index * 0.05);
            orb.style.transform = `translate(${scrolled * speed}px, ${scrolled * speed * 0.5}px)`;
        });
    }

    // Initialize animations
    function initAnimations() {
        if (!window.IntersectionObserver) return;

        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('aos-animate');
                }
            });
        }, observerOptions);

        document.querySelectorAll('[data-aos]').forEach(element => {
            observer.observe(element);
        });
    }

    // Initialize counters
    function initCounters() {
        const counters = document.querySelectorAll('.counter');
        if (counters.length === 0) return;

        const speed = 200;

        const animateCounter = (counter) => {
            const target = parseInt(counter.getAttribute('data-target'));
            const increment = target / speed;
            let current = 0;

            const updateCounter = () => {
                current += increment;
                if (current < target) {
                    counter.textContent = Math.ceil(current);
                    requestAnimationFrame(updateCounter);
                } else {
                    counter.textContent = target;
                }
            };

            updateCounter();
        };

        if (!window.IntersectionObserver) {
            counters.forEach(counter => animateCounter(counter));
            return;
        }

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateCounter(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });

        counters.forEach(counter => observer.observe(counter));
    }

    // Initialize lazy loading
    function initLazyLoading() {
        const images = document.querySelectorAll('img[loading="lazy"]');
        
        if (!window.IntersectionObserver || images.length === 0) return;

        const imageObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const img = entry.target;
                    if (img.dataset.src) {
                        img.src = img.dataset.src;
                    }
                    img.classList.add('loaded');
                    observer.unobserve(img);
                }
            });
        });

        images.forEach(img => imageObserver.observe(img));
    }

    // Initialize notifications
    function initNotifications() {
        const placeholderLinks = document.querySelectorAll('a[href^="#ebooks"], a[href^="#guias"], a[href^="#blog"], a[href^="#herramientas"], a[href^="#faq"], a[href^="#privacidad"], a[href^="#terminos"], a[href^="#cookies"]');
        
        placeholderLinks.forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.getAttribute('href').substring(1);
                showNotification(section);
            });
        });
    }

    function showNotification(section) {
        const messages = {
            'ebooks': '📚 La sección de eBooks estará disponible próximamente',
            'guias': '🗺️ Las Guías Prácticas están en desarrollo',
            'blog': '📰 El Blog estará activo muy pronto',
            'herramientas': '🛠️ El directorio de Herramientas IA viene en camino',
            'faq': '❓ Sección de FAQ en construcción',
            'privacidad': '🔒 Política de Privacidad en preparación',
            'terminos': '📄 Términos de Uso en preparación',
            'cookies': '🍪 Política de Cookies en preparación'
        };

        const message = messages[section] || '⏳ Esta sección estará disponible próximamente';
        
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;
        notification.style.cssText = `
            position: fixed;
            bottom: 30px;
            right: 30px;
            background: linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%);
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 12px;
            box-shadow: 0 8px 24px rgba(99, 102, 241, 0.4);
            z-index: 10000;
            animation: slideInUp 0.3s ease;
            max-width: 320px;
            font-weight: 600;
        `;

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.animation = 'slideOutDown 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    // Keyboard navigation
    function initKeyboard() {
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                const navToggle = document.getElementById('navToggle');
                const navLinks = document.getElementById('navLinks');
                if (navToggle?.classList.contains('active')) {
                    navToggle.classList.remove('active');
                    navLinks?.classList.remove('active');
                }
            }
            
            if ((e.ctrlKey || e.metaKey) && e.key === 'ArrowUp') {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
            }
        });
    }

    // Add dynamic styles
    function addDynamicStyles() {
        const style = document.createElement('style');
        style.textContent = `
            @keyframes slideInUp {
                from { transform: translateY(100%); opacity: 0; }
                to { transform: translateY(0); opacity: 1; }
            }

            @keyframes slideOutDown {
                from { transform: translateY(0); opacity: 1; }
                to { transform: translateY(100%); opacity: 0; }
            }

            .notification {
                font-family: 'Inter', sans-serif;
            }

            img {
                transition: opacity 0.3s ease;
            }

            img.loaded {
                animation: fadeIn 0.5s ease;
            }

            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }

            .btn, .btn-card, .btn-nav {
                position: relative;
                overflow: hidden;
            }

            .btn::before, .btn-card::before, .btn-nav::before {
                content: '';
                position: absolute;
                top: 50%;
                left: 50%;
                width: 0;
                height: 0;
                border-radius: 50%;
                background: rgba(255, 255, 255, 0.3);
                transform: translate(-50%, -50%);
                transition: width 0.6s, height 0.6s;
            }

            .btn:active::before, .btn-card:active::before, .btn-nav:active::before {
                width: 300px;
                height: 300px;
            }
        `;
        document.head.appendChild(style);
    }

    // Performance monitoring
    function monitorPerformance() {
        if (window.performance) {
            window.addEventListener('load', () => {
                setTimeout(() => {
                    const perfData = window.performance.timing;
                    const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
                    console.log(`⚡ Page loaded in ${pageLoadTime}ms`);
                }, 0);
            });
        }
    }

    // Console message
    function showConsoleMessage() {
        console.log(`
%c🧠 AnticrashIA %c- Landing Page Premium
%cDesarrollado con dedicación para quienes no se quedan atrás.
%c¿Interesado en el código? Contáctanos!
`,
        'color: #6366F1; font-size: 24px; font-weight: bold;',
        'color: #8B5CF6; font-size: 16px;',
        'color: #a1a1aa; font-size: 14px;',
        'color: #06B6D4; font-size: 14px; font-weight: bold;'
        );
    }

    // Initialize everything
    function init() {
        console.log('🧠 AnticrashIA Landing Page initialized');
        
        // Hide loading immediately
        hideLoadingOverlay();
        
        // Initialize all features
        initNavigation();
        initScrollEffects();
        initAnimations();
        initCounters();
        initLazyLoading();
        initNotifications();
        initKeyboard();
        addDynamicStyles();
        monitorPerformance();
        showConsoleMessage();
    }

    // Wait for DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Error handling
    window.addEventListener('error', (e) => {
        console.error('❌ Error detected:', e.message);
    });

})();
